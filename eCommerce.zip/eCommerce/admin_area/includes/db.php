<?php

$con = mysqli_connect("localhost","root","root","ecom_store");

?>
